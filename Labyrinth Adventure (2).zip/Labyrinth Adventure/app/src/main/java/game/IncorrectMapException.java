package game;

public class IncorrectMapException extends Exception{
    public IncorrectMapException(String desc)
    {
        super(desc);
    }
}
